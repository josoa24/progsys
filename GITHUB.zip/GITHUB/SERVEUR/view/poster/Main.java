package view.poster;

import javax.swing.UIManager;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

import model.Serveur;

public class Main {
    public static void main(String[] args) throws Exception {
        UIManager.setLookAndFeel(new NimbusLookAndFeel());

        Serveur server = new Serveur();
        server.startServer();
       

    }
}
