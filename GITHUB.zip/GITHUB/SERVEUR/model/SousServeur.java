package model;

import java.io.*;
import java.net.*;

public class SousServeur {
    private String host;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    private int port;
    private String cheminStockage;

    public SousServeur(String host, int port, String cheminStockage) {
        this.host = host;
        this.port = port;
        this.cheminStockage = cheminStockage;
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Sous-serveur démarré sur le port " + port);
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Connexion du serveur principal reçue.");
                receiveFragment(socket);
            }
        } catch (IOException e) {
            System.err.println("Erreur du sous-serveur : " + e.getMessage());
        }
    }

    private void receiveFragment(Socket socket) {
        try (DataInputStream in = new DataInputStream(socket.getInputStream())) {
            // Recevoir le nom du fragment de fichier
            String fragmentName = in.readUTF();
            System.out.println("Réception du fragment : " + fragmentName);

            // Sauvegarde du fragment dans le chemin de stockage
            File file = new File(cheminStockage + File.separator + fragmentName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
                System.out.println("Fragment " + fragmentName + " sauvegardé dans " + file.getAbsolutePath());
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de la réception du fragment : " + e.getMessage());
        }
    }

    /*
     * public static void main(String[] args) {
     * // Exemple d'initialisation d'un sous-serveur
     * SousServeur sousServeur1 = new SousServeur("localhost", 4001,
     * "home/miarisoa/Documents/SOCKET.VF(2)/SOCKET.VF/un");
     * SousServeur sousServeur2 = new SousServeur("localhost", 4002,
     * "home/miarisoa/Documents/SOCKET.VF(2)/SOCKET.VF/deux");
     * SousServeur sousServeur3 = new SousServeur("localhost", 4003,
     * "home/miarisoa/Documents/SOCKET.VF(2)/SOCKET.VF/trois");
     * 
     * // Lancer chaque sous-serveur dans son propre thread
     * new Thread(() -> sousServeur1.start()).start();
     * new Thread(() -> sousServeur2.start()).start();
     * new Thread(() -> sousServeur3.start()).start();
     * 
     * 
     * }
     */
}
