package model;

import java.io.*;
import java.net.*;
import java.util.*;
import config.Config;

public class Serveur {
    Config conf;

    public Config getConf() {
        return conf;
    }

    public Serveur() {
        conf = new Config();
    }

    private void sauvegarderFichierDivise(InputStream in, String[][] sousServeurs, String nomFichier, long taillePartie,
            long reste) throws IOException {
        byte[] buffer = new byte[4096];
        int bytesRead;

        // Liste des chemins complets des fragments
        List<String> cheminsFragments = new ArrayList<>();

        for (int i = 0; i < sousServeurs.length; i++) {
            String host = sousServeurs[i][0];
            int port = Integer.parseInt(sousServeurs[i][1]);

            // Récupération du chemin de stockage
            String cheminStockage = conf.getCheminStockage()[i];

            // Création du fichier pour le fragment
            String fragmentName = "partie" + (i + 1) + "_" + nomFichier;
            File fragmentFile = new File(cheminStockage, fragmentName);

            // Vérification et création du répertoire si nécessaire
            File directory = new File(cheminStockage);
            if (!directory.exists()) {
                directory.mkdirs();
            }

            try (Socket socket = new Socket(host, port);
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                    FileOutputStream fileOut = new FileOutputStream(fragmentFile)) {

                // Calcul de la taille du fragment
                long tailleACopier = (i == sousServeurs.length - 1) ? taillePartie + reste : taillePartie;
                long bytesRestants = tailleACopier;

                out.writeUTF(fragmentName); // Envoi du nom du fragment au sous-serveur
                System.out.println("Envoi du fragment " + fragmentName + " au sous-serveur " + host + ":" + port);

                // Lecture et envoi des données du fragment
                while (bytesRestants > 0) {
                    int tailleLecture = (int) Math.min(buffer.length, bytesRestants);
                    bytesRead = in.read(buffer, 0, tailleLecture);

                    if (bytesRead == -1) {
                        System.err.println("Erreur : fin du flux avant de terminer la partie " + (i + 1));
                        break;
                    }

                    fileOut.write(buffer, 0, bytesRead); // Écriture des données dans le fragment
                    out.write(buffer, 0, bytesRead); // Envoi au sous-serveur
                    bytesRestants -= bytesRead;
                }

                // Ajout du chemin complet du fragment pour l'enregistrement
                cheminsFragments.add(fragmentFile.getAbsolutePath());
                System.out.println("Fragment envoyé et enregistré : " + fragmentFile.getAbsolutePath());

            } catch (IOException e) {
                System.err.println("Erreur lors de l'envoi du fragment au sous-serveur : " + e.getMessage());
            }
        }

        // Enregistrer les chemins des fragments
        enregistrerCheminsSousFichiers(nomFichier, cheminsFragments);
    }

    private static void enregistrerCheminsSousFichiers(String nomFichier, List<String> cheminsFragments) {
        File historyDir = new File("history/");
        if (!historyDir.exists()) {
            historyDir.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("history/" + nomFichier + "_repartition.txt"))) {
            for (String chemin : cheminsFragments) {
                writer.write(chemin);
                writer.newLine();
            }
            System.out.println("Chemins des fragments enregistrés dans " + nomFichier + "_repartition.txt");
        } catch (IOException e) {
            System.err.println("Erreur lors de l'enregistrement des chemins des fragments : " + e.getMessage());
        }
    }

    private void regrouperSousFichiers(String nomFichier, OutputStream out) throws IOException {
        // Chemins des fragments
        String[] cheminStockage = conf.getCheminStockage();

        // Chemin pour le dossier downloads
        // File downloadsDir = new File(".//
        File fichierRegroupe = new File(nomFichier);

        try (BufferedOutputStream bos = new BufferedOutputStream(out);
                FileOutputStream fichierRegroupeStream = new FileOutputStream(fichierRegroupe)) {

            for (int i = 0; i < cheminStockage.length; i++) {
                String fragmentName = "partie" + (i + 1) + "_" + nomFichier; // Nom du fragment
                File fragmentFile = new File(cheminStockage[i], fragmentName); // Chemin complet du fragment

                if (!fragmentFile.exists()) {
                    System.err.println("Fragment manquant : " + fragmentFile.getPath());
                    continue; // Passer au fragment suivant
                }

                try (FileInputStream fragmentInput = new FileInputStream(fragmentFile)) {
                    System.out.println("Récupération du fragment : " + fragmentFile.getPath());

                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fragmentInput.read(buffer)) != -1) {
                        bos.write(buffer, 0, bytesRead); // Envoyer au client
                        fichierRegroupeStream.write(buffer, 0, bytesRead); // Sauvegarder dans downloads
                    }
                } catch (IOException e) {
                    System.err.println("Erreur lors de la lecture du fragment : " + fragmentFile.getPath());
                }
            }

            System.out.println("Fichier " + nomFichier + " regroupé et envoyé au client.");
            System.out.println("Fichier également sauvegardé dans downloads/" + nomFichier);
        }
    }

    public void televerser(DataInputStream dataIn, InputStream in) {
        try {
            String nomFichier = dataIn.readUTF();
            System.out.println("Nom du fichier reçu : " + nomFichier);

            File fichierReception = new File("./downloads_client/", "reception.txt");
            try (FileWriter writer = new FileWriter(fichierReception, true)) {
                writer.write(nomFichier + System.lineSeparator());
            } catch (Exception e) {
                System.out.println("Erreur enregistrer pour lire apres " + e.getMessage());
            }

            long tailleFichier = dataIn.readLong();
            System.out.println("Taille du fichier : " + tailleFichier + " octets");

            if (tailleFichier <= 0) {
                System.err.println("Erreur : taille du fichier invalide.");
            }

            long taillePartie = tailleFichier / 3;
            long reste = tailleFichier % 3;

            sauvegarderFichierDivise(in, conf.getSousServeurs(), nomFichier, taillePartie, reste);
        } catch (IOException e) {
            System.err.println("Erreur pendant la réception du fichier : " + e.getMessage());
        }
    }

    public void telecharger(DataInputStream dataIn, OutputStream out) {
        try {
            String nomFichierDemande = dataIn.readUTF();
            System.out.println("Demande de récupération du fichier : " + nomFichierDemande);
            regrouperSousFichiers(nomFichierDemande, out);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(conf.getPort())) {
            System.out.println("Serveur démarré sur le port " + conf.getPort());
            SousServeur[] unders = new SousServeur[3];

            // demarrage des sous serveurs en meme temps que le principal
            for (int i = 0; i < 3; i++) {
                int port = Integer.parseInt(conf.getSousServeurs()[i][1]);
                String host = conf.getSousServeurs()[i][0];
                String cheminStockage = conf.getCheminStockage()[i];
                unders[i] = new SousServeur(host, port, cheminStockage);
                int index = i;
                new Thread(() -> {
                    unders[index].start();
                    System.out.println("Sous-Serveur " + index + " démarré");
                }).start();
            }
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nouveau client connecté : " + clientSocket.getInetAddress());
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Erreur du serveur : " + e.getMessage());
        }
    }

    /*
     * private void handleClient(Socket clientSocket) {
     * try (DataInputStream in = new DataInputStream(clientSocket.getInputStream());
     * DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream()))
     * {
     * String command;
     * while ((command = in.readUTF()) != null) {
     * System.out.println("Commande reçue : " + command);
     * 
     * if (command.equalsIgnoreCase("exit")) {
     * System.out.println("Client déconnecté.");
     * break;
     * } else if (command.equalsIgnoreCase("put")) {
     * televerser(in, clientSocket.getInputStream());
     * } else if (command.equalsIgnoreCase("get")) {
     * telecharger(in, out);
     * } else if (command.equalsIgnoreCase("ls")) {
     * out.writeUTF(listFiles());
     * } else if (command.equalsIgnoreCase("rm")) {
     * System.out.println(in.readUTF());
     * 
     * }
     * else {
     * out.writeUTF("Commande inconnue : " + command);
     * }
     * }
     * } catch (IOException e) {
     * System.err.println("Erreur avec le client : " + e.getMessage());
     * }
     * }
     */

    private void supprimerLigne(String ligneASupprimer, String fichier) {
        File file = new File(fichier);
        File tempFile = new File(fichier + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(file));
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String currentLine;

            while ((currentLine = reader.readLine()) != null) {
                // Supprimer uniquement la ligne correspondante
                if (currentLine.trim().equals(ligneASupprimer.trim())) {
                    System.out.println("Ligne supprimée : " + currentLine);
                    continue;
                }
                writer.write(currentLine);
                writer.newLine();
            }

            // Remplacement du fichier original par le fichier temporaire
            if (file.delete()) {
                tempFile.renameTo(file);
            }

        } catch (IOException e) {
            System.err.println("Erreur lors de la suppression de la ligne : " + e.getMessage());
        }
    }

    private void supprimerFragments(String nomFichier) {
        String cheminRepartition = "./history/" + nomFichier + "_repartition.txt";
        File fichierRepartition = new File(cheminRepartition);

        if (!fichierRepartition.exists()) {
            System.err.println("Le fichier de répartition " + cheminRepartition + " n'existe pas.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(fichierRepartition))) {
            String cheminFragment;
            while ((cheminFragment = reader.readLine()) != null) {
                File fragment = new File(cheminFragment);
                if (fragment.exists()) {
                    if (fragment.delete()) {
                        System.out.println("Fragment supprimé : " + cheminFragment);
                    } else {
                        System.err.println("Échec de la suppression du fragment : " + cheminFragment);
                    }
                } else {
                    System.err.println("Le fragment n'existe pas : " + cheminFragment);
                }
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de la lecture du fichier de répartition : " + e.getMessage());
        }
    }

    private void supprimerFichier(String nomFichier) {
        String cheminRepartition = "./history/" + nomFichier + "_repartition.txt";
        File fichierRepartition = new File(cheminRepartition);

        if (fichierRepartition.exists()) {
            if (fichierRepartition.delete()) {
                System.out.println("Fichier de répartition supprimé : " + cheminRepartition);
            } else {
                System.err.println("Échec de la suppression du fichier de répartition : " + cheminRepartition);
            }
        } else {
            System.err.println("Le fichier de répartition " + cheminRepartition + " n'existe pas.");
        }
    }

    private void handleClient(Socket clientSocket) {
        try (DataInputStream in = new DataInputStream(clientSocket.getInputStream());
                DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream())) {

            String command;
            while ((command = in.readUTF()) != null) {
                System.out.println("Commande reçue : " + command);

                if (command.equalsIgnoreCase("exit")) {
                    System.out.println("Client déconnecté.");
                    break;

                } else if (command.equalsIgnoreCase("put")) {
                    televerser(in, clientSocket.getInputStream());

                } else if (command.equalsIgnoreCase("get")) {
                    telecharger(in, out);
                    

                } else if (command.equalsIgnoreCase("ls")) {
                    out.writeUTF(listFiles());

                } else if (command.equalsIgnoreCase("rm")) {
                    String nomFichier = in.readUTF();
                    System.out.println("Suppression demandée pour le fichier : " + nomFichier);

                    // Supprimer les fragments
                    supprimerFragments(nomFichier);

                    // Supprimer le fichier de répartition
                    supprimerFichier(nomFichier);

                    // suppression de ligne dans la liste des fichiers downloades
                    supprimerLigne(nomFichier, "./downloads_client/reception.txt");
                } else {
                    out.writeUTF("Commande inconnue : " + command);
                }
            }
        } catch (IOException e) {
            System.err.println("Erreur avec le client : " + e.getMessage());
        }
    }

    private String listFiles() {
        StringBuilder contenu = new StringBuilder();
        try {
            BufferedReader read = new BufferedReader(new FileReader(new File("./downloads_client/reception.txt")));
            String line;
            while ((line = read.readLine()) != null) {
                System.out.println(line);
                contenu.append(line).append("\n");
            }
            read.close();
        } catch (Exception e) {
            System.out.println("Erreur lecture reception.txt : " + e.getMessage());
        }
        if (contenu.length() == 0) {
            return "Aucun fichier disponible.";
        }
        return contenu.toString();
    }

}
