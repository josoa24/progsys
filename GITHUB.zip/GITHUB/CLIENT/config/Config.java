package config;

public class Config {
    private final int port = 3214;
    // private final String host = "172.20.245.89";
    // private final String host = "192.168.43.126";
    private final String host = "localhost";

    public String getHost() {
        return host;
    }

    private final String[] cheminStockage = new String[] {
           "stockage/un",
           "stockage/deux",
           "stockage/trois",
    };

    private final String[][] sousServeurs = new String[][] {
        { "localhost", "4001" }, 
        { "localhost", "4002" }, 
        { "localhost", "4003" }  
    };

    public String[][] getSousServeurs() {
        return sousServeurs;
    }

    public int getPort() {
        return port;
    }

    public String[] getCheminStockage() {
        return cheminStockage;
    }

}