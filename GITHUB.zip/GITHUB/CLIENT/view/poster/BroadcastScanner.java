package view.poster;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashSet;
import java.util.Set;

public class BroadcastScanner {

    public static void main(String[] args) {
        Set<String> ipAddresses = getConnectedIPAddresses();
        System.out.println("Adresses IP connectées sur le même réseau :");
        for (String ip : ipAddresses) {
            System.out.println(ip);
        }
    }

    public static Set<String> getConnectedIPAddresses() {
        Set<String> ipAddresses = new HashSet<>();
        DatagramSocket socket = null;

        try {
            // Créer une socket UDP
            socket = new DatagramSocket();
            socket.setBroadcast(true);

            // Adresse de broadcast (exemple : 255.255.255.255)
            InetAddress broadcastAddress = InetAddress.getByName("192.168.43.255");
            String message = "DISCOVER_REQUEST"; // Message de découverte
            byte[] buffer = message.getBytes();

            // Envoyer le message de broadcast
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, broadcastAddress, 8888);
            socket.send(packet);

            // Écouter les réponses
            byte[] responseBuffer = new byte[1024];
            for (int i = 0; i < 5; i++) { // Attendre plusieurs réponses
                DatagramPacket responsePacket = new DatagramPacket(responseBuffer, responseBuffer.length);
                socket.receive(responsePacket);
                String responseIP = responsePacket.getAddress().getHostAddress();
                ipAddresses.add(responseIP);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }

        return ipAddresses;
    }
}