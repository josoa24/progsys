package view.interfaces;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.*;

public class MyWindows extends JFrame {
    Login login;

    public MyWindows() throws Exception {
        super("JOSOA (ETU003213) &&  Miarisoa (ETU00XXXX)");

        // Logique

        // Affichage
        this.setSize(940, 1080);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Color

        this.setLocationRelativeTo(null);
        this.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 0.25;
        gbc.weighty = 1.0;
        gbc.gridx = 0;
        gbc.gridy = 0;
        // this.getContentPane().add(leftPanel, gbc);
        gbc.weightx = 0.75;
        gbc.gridx = 1;
        // this.getContentPane().add(panelPrincipale, gbc);

        this.setVisible(true);
        this.login = new Login(this);
        this.getContentPane().add(login);
    }

    public void nonSense() {

    }
}
