package view.interfaces;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Login extends JPanel {
    MyWindows windows;

    public Login(MyWindows windows) {
        JDialog dialog = new JDialog(windows, "Start Simulation", true);
        dialog.setLayout(null);
        dialog.setBounds(500, 250, 400, 300);

        JLabel portLabel = new JLabel("Port");
        portLabel.setHorizontalAlignment(JTextField.CENTER);
        JTextField portField = new JTextField("3213");
        portField.setHorizontalAlignment(JTextField.CENTER);

        JLabel hostLabel = new JLabel("Host");
        hostLabel.setHorizontalAlignment(JTextField.CENTER);
        JTextField hostField = new JTextField("127.0.0.1");
        hostField.setHorizontalAlignment(JTextField.CENTER);

        JButton connect = new JButton("Connect");
        dialog.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int panelWidth = dialog.getWidth();
                int buttonWidth = (int) (panelWidth * 0.95);
                int buttonWidthPort = (int) (panelWidth * 0.72);
                int labelWidthPort = (int) (panelWidth * 0.2);
                portLabel.setBounds(10, 70, labelWidthPort, 40);
                portField.setBounds(100, 70, buttonWidthPort, 40);
                hostLabel.setBounds(10, 130, labelWidthPort, 40);
                hostField.setBounds(100, 130, buttonWidthPort, 40);
                connect.setBounds(10, 200, buttonWidth, 40);
            }
        });

        dialog.add(portLabel);
        dialog.add(portField);
        dialog.add(hostLabel);
        dialog.add(hostField);
        dialog.add(connect);
        dialog.setVisible(true);
    }
}
