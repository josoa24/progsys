package model;

import java.io.*;
import java.net.*;
import java.util.Scanner;

import config.Config;

public class Client {
    private final Config conf;
    private Socket socket;
    private final Command commands;

    public Client() {
        conf = new Config();
        commands = new Command();
    }

    public Config getConf() {
        return conf;
    }

    public void connect() {
        try (Socket socket = new Socket(conf.getHost(), conf.getPort());
                DataOutputStream output = new DataOutputStream(socket.getOutputStream());
                DataInputStream input = new DataInputStream(socket.getInputStream());
                Scanner scanner = new Scanner(System.in)) {

            this.socket = socket;
            System.out.println("Connexion réussie au serveur " + conf.getHost() + " : " + conf.getPort());
            Boolean found = true;
            String serverMessage;
            String userCommand = "";
            while (true) {
                if (found) {
                    System.out.print("File Transfer ==> ");
                    userCommand = scanner.nextLine();
                }

                if (commands.inCommandList(userCommand)) {
                    if (found) {
                        output.writeUTF(userCommand);
                        output.flush();
                    }

                    if (userCommand.equals("exit")) {
                        System.out.println("Déconnexion...");
                        break;
                    } else if (userCommand.equals("put")) {
                        System.out.print("Entrez le chemin du fichier à envoyer : ");
                        String filePath = scanner.nextLine();
                        if (new File(filePath).exists()) {
                            found = true;
                            envoyerFichier(filePath);
                        } else {
                            found = false;
                            userCommand = "put";
                            System.out.println("Fichier non trouve");
                        }
                    } else if (userCommand.equals("get")) {
                        System.out.print("Entrez le nom du fichier à télécharger : ");
                        String fileName = scanner.nextLine();
                        demanderFichier(fileName);
                    } else if (userCommand.equals("ls")) {
                        serverMessage = input.readUTF();
                        System.out.println(serverMessage);
                    } else if (userCommand.equals("rm")) {
                        System.out.print("Entrez le nom du fichier à supprimer : ");
                        String fileName = scanner.nextLine();
                        output.writeUTF(fileName);
                    } else {
                        serverMessage = input.readUTF();
                        System.out.println("Serveur : " + serverMessage);
                    }
                } else {
                    System.out.println("Commande inconnue : " + userCommand);
                }
            }

        } catch (

        IOException e) {
            // connect();
            System.err.println("Erreur côté client : " + e.getMessage());
        }
    }

    public void envoyerFichier(String cheminFichier) {
        File fichier = new File(cheminFichier);
        if (!fichier.exists()) {
            System.err.println("Erreur : le fichier n'existe pas.");
            return;
        }

        try (FileInputStream fis = new FileInputStream(fichier)) {
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            // Envoi du nom et de la taille du fichier
            out.writeUTF(fichier.getName());
            out.writeLong(fichier.length());

            System.out.println("Envoi du fichier " + fichier.getName() + " (" + fichier.length() + " octets)");

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
            System.out.println("Fichier envoyé avec succès.");
        } catch (IOException e) {
            System.err.println("Erreur lors de l'envoi du fichier : " + e.getMessage());
        }
    }

    public void demanderFichier(String nomFichier) {
        try (DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                DataInputStream in = new DataInputStream(socket.getInputStream());
                FileOutputStream fos = new FileOutputStream("./downloads/" + nomFichier)) {
            out.writeUTF(nomFichier);
            System.out.print("Téléchargement du fichier " + nomFichier + "...");
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                System.out.print(".");
            }
            System.out.println(".");
            System.out.println("Fichier " + nomFichier + " téléchargé avec succès !");
        } catch (IOException e) {
            System.err.println("Erreur lors du téléchargement du fichier : " + e.getMessage());
        }
    }

}
