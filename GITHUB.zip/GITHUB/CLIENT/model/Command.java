package model;

public class Command {
    String[] commands = new String[] { "ls", "exit", "put", "get", "rm" };

    public String[] getCommands() {
        return commands;
    }

    public void setCommands(String[] commands) {
        this.commands = commands;
    }

    public boolean  inCommandList(String command){
        for (String string : commands) {
            if(command.equals(string)){
                return true;
            }
        }
        return false;
    }
}
